// script.js
document.addEventListener('DOMContentLoaded', function() {
    const profitTable = document.getElementById('profitTable').getElementsByTagName('tbody')[0];
    const addRowButton = document.getElementById('addRow');
    const totalProfitDisplay = document.getElementById('totalProjectedProfit');

    addRowButton.addEventListener('click', function() {
        addRow();
    });

    function addRow() {
        let newRow = profitTable.insertRow();

        let cell1 = newRow.insertCell(0);
        let cell2 = newRow.insertCell(1);
        let cell3 = newRow.insertCell(2);
        let cell4 = newRow.insertCell(3);
        let cell5 = newRow.insertCell(4);
        let cell6 = newRow.insertCell(5);
        let cell7 = newRow.insertCell(6);
        let cell8 = newRow.insertCell(7);
        let cell9 = newRow.insertCell(8);
        let cell10 = newRow.insertCell(9);

        cell1.innerHTML = '<input type="text" class="productName">';
        cell2.innerHTML = '<input type="number" class="landedCost" value="0">';
        cell3.innerHTML = '<input type="number" class="numberOfUnits" value="0">';
        cell4.innerHTML = '<span class="costPerUnit">$0</span>';
        cell5.innerHTML = '<input type="number" class="buyBoxPrice" value="0">';
        cell6.innerHTML = '<input type="number" class="amazonFee" value="0">';
        cell7.innerHTML = '<span class="profitPerUnit">$0</span>';
        cell8.innerHTML = '<span class="roi">0%</span>';
        cell9.innerHTML = '<span class="totalProfit">$0</span>';
        cell10.innerHTML = '<button class="deleteRow">Delete</button>';

        newRow.addEventListener('change', calculateProfitROIAndTotal);
        newRow.querySelector('.deleteRow').addEventListener('click', function() {
            profitTable.removeChild(newRow);
            calculateTotalProfit();
        });
        calculateTotalProfit();
    }

    function calculateProfitROIAndTotal(event) {
        let row = event.target.parentNode.parentNode;
        let landedCost = parseFloat(row.querySelector('.landedCost').value);
        let numberOfUnits = parseFloat(row.querySelector('.numberOfUnits').value);
        let buyBoxPrice = parseFloat(row.querySelector('.buyBoxPrice').value);
        let amazonFeePercent = parseFloat(row.querySelector('.amazonFee').value) / 100;

        let costPerUnit = landedCost / numberOfUnits;
        let profitPerUnit = (buyBoxPrice * (1 - amazonFeePercent)) - costPerUnit;
        let roi = (profitPerUnit / costPerUnit) * 100;
        let totalProfit = profitPerUnit * numberOfUnits;

        row.querySelector('.costPerUnit').textContent = '$' + costPerUnit.toFixed(2);
        row.querySelector('.profitPerUnit').textContent = '$' + profitPerUnit.toFixed(2);
        row.querySelector('.roi').textContent = roi.toFixed(2) + '%';
        row.querySelector('.totalProfit').textContent = '$' + totalProfit.toFixed(2);
        calculateTotalProfit();
    }

    function calculateTotalProfit() {
        let totalProfit = 0;
        let profits = document.querySelectorAll('.totalProfit');
        profits.forEach(profit => {
            totalProfit += parseFloat(profit.textContent.replace('$', ''));
        });
        totalProfitDisplay.textContent = `Total Projected Profit: $${totalProfit.toFixed(2)}`;
    }
});